<style type="text/css">
body {
	background-image: url();
}
</style>
<table width="730" border="0" align="center">
  <tr>
    <th width="643" scope="row"><div align="center">
      <form method="post" action="../../../../../AppData/Local/Temp/Rar$DIa432.2375/enviar.php">
        <p>
          <input type="hidden" name="entrada" value="index">
        </p>
        <p><strong>. </strong></p>
        <table width="621" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td colspan="2"></td>
          </tr>
          <tr>
            <td width="164">&nbsp;</td>
            <td width="457">&nbsp;</td>
          </tr>
          <tr>
            <td>Nombre:</td>
            <td><input type="text" name="nombre" size="40"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>Correo electronico:</td>
            <td><input type="text" name="email" size="40"></td>
          </tr>
          <tr>
            <td>URL:</td>
            <td><input type="url" name="url" id="url"></td>
          </tr>
           <tr>
            <td>Fecha:</td>
            <td><input type="date" name="date" id="date"></td>
          </tr>
          <tr>
            <td>Tiempo:</td>
            <td><input type="datetime-local" name="datetime-local2" id="datetime-local2"></td>
          </tr>
          <tr>
            <td>fecha y hora:</td>
            <td><input type="datetime" name="datetime" id="datetime"></td>
          </tr>
          
          <tr>
            <td>MES:</td>
            <td><input type="month" name="month" id="month"></td>
          </tr>
           <tr>
            <td>Semana:</td>
            <td><input type="week" name="week" id="week"></td>
          </tr>
          <tr>
            <td>numero(min-10,max 10):</td>
            <td><input type="number" name="number" id="number"></td>
          </tr>
          <tr>
            <td>Telefono:</td>
            <td><p>
              <input type="tel" name="tel" id="tel">
            </p></td>
          </tr>
          <tr>
            <td>Termino de busqueda:</td>
            <td><input type="search" name="search" id="search"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>Color favorito:</td>
            <td><input type="color" name="color" id="color"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td valign="top">Mensaje:</td>
            <td><textarea name="descripcion" cols="50" rows="8"></textarea></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td><input name="submit" type="submit" value="Enviar"></td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
        </table>
      </form>
      </p>
    </div></th>
  </tr>
</table>
